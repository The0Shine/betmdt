export interface IApiError {
    code: number;
    title: string;
    detail: string;
}
